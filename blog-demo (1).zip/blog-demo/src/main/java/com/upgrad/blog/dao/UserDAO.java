package com.upgrad.blog.dao;

/**
 * TODO: 6.5. Implement the UserCRUD interface.
 * TODO: 6.6. findByEmail() method should take email id as an input parameter and
 * return the user details corresponding to the email id from the USERS table defined
 * in the database.
 * TODO: 6.7. create() method should take user details as input and insert these details
 * into the USERS table. Return the same UserDAO object which was passed as an input argument.
 */
public class UserDAO {



    
//    public static void main(String[] args) {
//		try {
//			UserDAO userDAO = new UserDAO();
//			UserDTO temp = new UserDTO();
//			temp.setUserId(1);
//			temp.setEmailId("temp@temp.temp");
//			temp.setPassword("temp");
//			userDAO.create(temp);
//			System.out.println(userDAO.findByEmail("temp@temp.temp"));
//		} catch (Exception e) {
//			System.out.println("FAILED");
//		}
//		
//		/**
//		 * Following should be the desired output of the main method.
//		 * UserDTO{userId=11, emailId='temp@temp.temp', password='temp'}
//		 */
//	}
}
